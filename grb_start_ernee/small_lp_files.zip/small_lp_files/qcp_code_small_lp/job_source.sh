#!/bin/sh
#$ -V
#$ -cwd
#$ -S /bin/bash
#$ -N QCP_baron4
#$ -o $JOB_NAME.o$JOB_ID
#$ -e $JOB_NAME.e$JOB_ID
#$ -q omni
#$ -pe sm 1
#$ -P quanah

module load gnu
sh 00compile.sh
./New_pcws_baron.exe > result_pcws_baron.txt
