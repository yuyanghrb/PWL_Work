#include "Funcs_Vars_MIQCP.h"
#include <ilcplex/ilocplex.h>
#include <iostream>
#include <fstream>
#include <ostream>
#include <stdio.h>
#include <ctype.h>
#include <stdlib.h>
#include <string.h>
#include <vector>
#include <math.h>
#include <ctime>
#include <time.h>
#include <iomanip>


using namespace std;

// Functions::Functions(int i, int j){
//   
//    set(i,j);  
//    rhs.resize(NUM_ROWS);
//    
// }

Functions::Functions(){
  
   rhs.resize(NUM_ROWS);
   
}

int Functions::getnumprob(){
  return NUMBER_OF_DIFFERENT_PROBLEMS;
}   

// void Functions::set(int i, int j){
//  
//   NUM_VAR = i;
//   NUM_ROWS = j;
// }

void Functions::CharSet(int l){
	  std::ostringstream mystream;  
	  mystream << "QCP_" << NUM_VAR << "_" << NUM_ROWS << "_" << SOS_SIZE << "_" << DENSITY_SOS << "_" << DENSITY_MEMBER << "_" << l << ".mod";
	  name_sos1_logM = mystream.str();
	  mystream.str(""); mystream.clear();
	  mystream << "QCP_" << NUM_VAR << "_" << NUM_ROWS << "_" << SOS_SIZE << "_" << DENSITY_SOS << "_" << DENSITY_MEMBER << "_" << l << ".lp";
	  name_sos1_log1 = mystream.str();			 // returns a string object with a copy of the current contents of the stream.
//	  cout << " name_sos1_log1 is " << name_sos1_log1 <<endl;
          mystream.str(""); mystream.clear();
	  mystream << "data_" << NUM_VAR << "_" << NUM_ROWS << "_" << SOS_SIZE << "_" << DENSITY_SOS << "_" << DENSITY_MEMBER << "_" << l << ".txt";
	  name_sos1_log2 = mystream.str();
//	  cout << " name_sos1_log2 is " << name_sos1_log2 <<endl;
          mystream.str(""); mystream.clear();
	  mystream << "Alglambdalp_" << NUM_VAR << "_" << NUM_ROWS << "_" << SOS_SIZE << "_" << DENSITY_SOS << "_" << DENSITY_MEMBER << "_" << l << ".lp";
	  name_sos1_log = mystream.str();
//	  cout << " name_sos1_log is "<< name_sos1_log <<endl;
          mystream.str(""); mystream.clear();
	  mystream << "DebugResults_" << NUM_VAR << "_" << NUM_ROWS << "_" << SOS_SIZE << "_" << DENSITY_SOS << "_" << DENSITY_MEMBER << "_" << l << ".txt";
	  name_sos1_log_debug = mystream.str();
//	  cout << " name_sos1_log_debug is "<< name_sos1_log_debug <<endl;
          mystream.str(""); mystream.clear();
// 	  mystream << "AlgDebugResults_" << NUM_VAR << "_" << NUM_ROWS << "_" << SOS_SIZE << "_" << DENSITY_SOS << "_" << DENSITY_MEMBER << "_" << l << ".txt";
// 	  name_sos1_log_debug1 = mystream.str();
// //	  cout << " name_sos1_log_debug1 is "<< name_sos1_log_debug1 <<endl;
//        mystream.str(""); mystream.clear();
	  mystream << "AlgDebugResults_" << NUM_VAR << "_" << NUM_ROWS << "_" << SOS_SIZE << "_" << DENSITY_SOS << "_" << DENSITY_MEMBER << ".txt";
	  name_sos1_log_debug1 = mystream.str();
//	  cout << " name_sos1_log_debug1 is "<< name_sos1_log_debug1 <<endl;
          mystream.str(""); mystream.clear();
	  mystream << "LP_Relaxations_"<< NUM_VAR << "_" << NUM_ROWS << "_" << SOS_SIZE << "_" << DENSITY_SOS << "_" << DENSITY_MEMBER << "_" << l << ".txt";
	  LP_relaxation = mystream.str();
//	  cout << "LP_relaxation is " << LP_relaxation << endl;
	  mystream.str(""); mystream.clear();
	  mystream << "Summary_" << NUM_VAR << "_" << NUM_ROWS << "_" << SOS_SIZE << "_" << DENSITY_SOS << "_" << DENSITY_MEMBER << ".txt";
	  Summary = mystream.str();
//	  cout << "Summary is " << Summary << endl;
	  mystream.str(""); mystream.clear();
	  mystream << "Count_sos_" << NUM_VAR << "_" << NUM_ROWS << "_" << SOS_SIZE << "_" << DENSITY_SOS << "_" << DENSITY_MEMBER << ".txt";
	  count_sos = mystream.str();
//	  cout << "Count_sos is " <<  count_sos<< endl;
	  mystream.str(""); mystream.clear();
	  mystream << "CPX_Summary_" << NUM_VAR << "_" << NUM_ROWS << "_" << SOS_SIZE << "_" << DENSITY_SOS << "_" << DENSITY_MEMBER << ".txt";
	  CPX_Summary = mystream.str();
//	  cout << "CPX_Summary is " << CPX_Summary << endl;
	  mystream.str(""); mystream.clear();
}







