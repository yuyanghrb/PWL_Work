/***************
FileName 		: SomeName.cpp
Description 	: This file generates the .mod and .lp for qcqp 
Author			: Yang Yu
Date Created	: 11/08/2017

TODO:
	1) some clean-up
	2) run piece-wise code
	3) 
****************/
#include "Funcs_Vars_MIQCP.h"
#include <iostream>
#include <fstream>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <ctime>

#define X_LOWER		0
#define X_UPPER		1
#define RHS_RATE	0.03

#define NUMBER_OF_FILES 3

int Functions::ipopt(){

int seed = 1;
using namespace std;

 
    ofstream shfile ("multi_mod.sh",fstream::out | fstream::app);
    
    

		shfile << "ampl " << name_sos1_logM << endl;				
      		seed = seed+1;
    

    shfile.close();



//convert sum.txt to a table.txt
//    	system("python sum_table.py");

//Create folder and Move files

	//system("mkdir LP_files");
	//system("mv *.lp LP_files");
	//system("mkdir Mod_files");
	//system("mv *.mod Mod_files");
	//system("mkdir Mod_results");
	//system("mv result* Mod_results");

  return 0;
}





