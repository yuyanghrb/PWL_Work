#include "Funcs_Vars_MIQCP.h"
#include <ilcplex/ilocplex.h>
#include <iostream>
#include <fstream>
#include <ostream>
#include <stdio.h>
#include <ctype.h>
#include <stdlib.h>
#include <string.h>
#include <vector>
#include <math.h>
#include <ctime>
#include <time.h>
#include <iomanip>

using namespace std;

int Functions::Algorithm(int n){

// Declare and allocate space for the variables and arrays where we will
//      store the optimization results including the status, objective value,
//      maximum bound violation, variable values, and basis.
//----------------------------------------------------------------------------
double coeffmtx[NUM_ROWS][NUM_VAR*2];     // stores the coeff matrix of constraints read in from "data.txt"
double L[NUM_VAR][MAX_BKPTS];             // stores current solutions for lambda values at each iteration
double newx[NUM_VAR], X_Steps[MAX_STEPS][NUM_VAR];                     // stores the new optimal solution at the end of each iteration
double rmatval[12];
double obj[NUM_VAR];
double coef;
double qobj[NUM_VAR];
double algtime, algobj;
double newobj[NUM_VAR*MAX_BKPTS], values[MAX_STEPS], Sum_L[NUM_VAR];
double l=0, u=1;
int count;
clock_t start_t, end_t, cpu_start, cpu_end;
//char summaryfile[1024]={'\0'};
std::string name_Relaxation;
std::ostringstream mystream;  // LP relaxation files
//---------------------------------------------------------------------------

// SOS-related Variables-----------------------------------------------------
int numsos = NUM_VAR; 
int numsosnz = NUM_BKPTS*NUM_VAR;
char sostype[numsos];
int sosind[numsos*(MAX_BKPTS+NUM_BKPTS)], sosbeg[numsos], sosvar[numsos][NUM_BKPTS + MAX_STEPS], brkptsoswt[NUM_VAR][MAX_BKPTS];
// int countsos[MAX_STEPS][NUM_VAR] = {0};
double soswt[numsos*(MAX_BKPTS+NUM_BKPTS)], wj[numsos][NUM_BKPTS+MAX_STEPS];
//---------------------------------------------------------------------------
      
// Cplex-related variables---------------------------------------------------
int      solnstat, solnmethod, solntype;
double   objval, maxviol;
double   lpobjval;
double   *x     = NULL;
int      *cstat = NULL;
int      *rstat = NULL;
string     basismsg;
int           status = 0;
int           cur_numrows, cur_numcols;
CPXENVptr     env = NULL;
CPXLPptr      lp = NULL;
CPXLPptr   newlp = NULL;
//----------------------------------------------------------------------------

// ================================================================================================
//Fill in the initial breakpoints, 0 and 1, for each variable.  Store in brkpt[][].
// ================================================================================================
    for (int i=0; i < NUM_VAR; i++){
	    for (int j=0; j<=1; j++){
		    if (j==0)
			    brkpt[i][j] = 0;
		    else
			    brkpt[i][j] = 1;
	    }
	}
// ================================================================================================
//Initializing the countsos matrix with zeros
// ================================================================================================
    memset(countsos, 0, sizeof(countsos[0][0])*MAX_STEPS*NUM_VAR);
    
// ================================================================================================ 

//cout << " name_sos1_log2 is " << name_sos1_log2 <<endl;
	ofstream inFile;

//	for (int m = 1; m <= n; m++) {

	inFile.open(name_sos1_log_debug1.c_str(),ios::app);                                                        //Read txt file containing constraint coefficients.
// 	inFile <<"Starting problem "<< n << " of " << NUMBER_OF_DIFFERENT_PROBLEMS << "\n";
// 	inFile <<"============================= Problem Information ============================="<<endl;
// 	inFile << "The constraint matrix coefficients:" << endl;
// 	for (int i = 0; i < NUM_ROWS; i++){
// 		for (int j = 0; j < NUM_VAR*2; j++){
// 		    for (int k = 0; k < SOS_SIZE; k++){
// 			inFile << a[i][j][k] << "   ";
// 			    }
// 			}
// 		inFile << endl;
// 	}
// 	
// 		inFile << "The objective function matrix coefficients:" << endl;
// 		inFile << "	The coefficients of linear terms:"<< endl;
// 		inFile << "	";
// 		for (int j = 0; j < NUM_VAR; j++){
// 		    for (int k = 0; k < SOS_SIZE; k++){
// 			inFile << sosobj[j][k] << "   ";
// 				//std::cout<<coeffmtx[a][b]<<std::endl;
// 			    }
// 			}
// 		inFile << endl;
// 		inFile << "	The coefficients of quadratic terms:" << endl;
// 		inFile << "	";
// 		for (int j = NUM_VAR; j < NUM_VAR*2; j++){
// 		    for (int k = 0; k < SOS_SIZE; k++){
// 			inFile << sosobj[j][k]/2 << "   ";
// 				//std::cout<<coeffmtx[a][b]<<std::endl;
// 			    }
// 			}
// 		inFile << endl;
// 		
// 		inFile << "The right-hand side matrix is:"<<endl;
// 		for (int i=0; i<NUM_ROWS; i++){
// 		  inFile << "	" << rhs[i] << endl;
// 		}

// ================================================================================================
//Printing the initial breakpoints for each variable
// ================================================================================================
// 	inFile <<"Variable Breakpoints (changing over the iterations): " << endl;                                                 
// 	for (int i=0; i< NUM_VAR; i++)
// 	{
// 		for (int j=0; j < NUM_BKPTS; j++)
// 		{
// 			inFile << "brkpt[" << i << "]" << "[" << j << "]= " << brkpt[i][j] << "   ";
// 		}
// 		inFile << endl;
// 	}
// 	inFile << "================================================================================" << endl;
// ================================================================================================

   /* Initialize the CPLEX environment */

   env = CPXopenCPLEX (&status);

   /* If an error occurs, the status value indicates the reason for
      failure.  A call to CPXgeterrorstring will produce the text of
      the error message.  Note that CPXopenCPLEX produces no output,
      so the only way to see the cause of the error is to use
      CPXgeterrorstring.  For other CPLEX routines, the errors will
      be seen if the CPXPARAM_ScreenOutput indicator is set to CPX_ON.  */

   if ( env == NULL ) {
      char  errmsg[CPXMESSAGEBUFSIZE];
      fprintf (stderr, "Could not open CPLEX environment.\n");
      CPXgeterrorstring (env, status, errmsg);
      fprintf (stderr, "%s", errmsg);
      goto TERMINATE;
   }

   /* Turn on output to the screen */

   status = CPXsetintparam (env, CPXPARAM_ScreenOutput, CPX_ON);
   if ( status ) {
      fprintf (stderr,
               "Failure to turn on screen indicator, error %d.\n", status);
      goto TERMINATE;
   }

// Create the problem, using the filename as the problem name 
// ================================================================================================
   
   lp = CPXcreateprob (env, &status, name_sos1_log1.c_str());
//    
// // ================================================================================================
//    
//    inFile << "Reading initial LP file name_sos1_log1 problem "<< m << " of " << NUMBER_OF_DIFFERENT_PROBLEMS << "\n";
// 
//    /* A returned pointer of NULL may mean that not enough memory
//       was available or there was some other problem.  In the case of
//       failure, an error message will have been written to the error
//       channel from inside CPLEX.  In this example, the setting of
//       the parameter CPXPARAM_ScreenOutput causes the error message to
//       appear on stdout.  Note that most CPLEX routines return
//       an error code to indicate the reason for failure.   */
// 
   if ( lp == NULL ) {
      fprintf (stderr, "Failed to create LP.\n");
      goto TERMINATE;
   }
// 
//    /* Now read the file, and copy the data into the created lp */
    
   status = CPXreadcopyprob (env, lp, name_sos1_log1.c_str(), NULL);
   if ( status ) {
      fprintf (stderr, "Failed to read and copy the problem data.\n");
      goto TERMINATE;
   }
//   inFile<<"Copied original LP to CPLEX Problem object\n\n";

   if ( CPXgetprobtype (env, lp) != CPXPROB_QCP ) {
      fprintf (stderr, "Input file is not a QCP.  Exiting.\n");
      goto TERMINATE;
   }
  
// ================================================================================================
// Get Coefficients of Linear Terms in Objective
// ================================================================================================
//    status = CPXgetobj (env, lp, obj, 0, NUM_VAR - 1);
//    if (status){
// 	   fprintf(stderr, "Failed to get quadrative Objective coefficients");
// 	   goto TERMINATE;
//    }
//    inFile << " Coefficients of Linear Terms in Objective" << endl;
//    for (int j = 0; j < NUM_VAR; j++) {
// 	   inFile << "Coeff Var "<< j+1 <<": " <<" Value = "<< obj[j] << endl;     
//   }
// =================================================================================================
   
// =================================================================================================
// Get Coefficients of Quadratic Terms in Objective
// ================================================================================================
//    inFile << " Coefficients of Quadratic Terms in Objective" << endl;	   
//    for (int j = 0; j < NUM_VAR; j++){
//        status = CPXgetqpcoef(env, lp, j, j, &coef);
//           if (status){
// 	   fprintf(stderr, "Failed to get quadrative Objective coefficients");
// 	   goto TERMINATE;
//    }
// 	   qobj[j] = coef;
// 	   inFile << "QP Coeff Var "<< j+1 <<": " <<" Value = "<< qobj[j]/2 << endl;
//    }
// ==================================================================================================


// ==================================================================================================
// Get the right-hand side values
// ==================================================================================================

//    inFile << " Coefficients of right-hand side matrix" << endl;
//    for (int j=0; j<NUM_ROWS; j++){
// 	     inFile << "rhs["<< j <<"]" << "= "<< rhs[j] << endl;   
//        }
// 
// // ================================================================================================
//    
//    for (int j = 0; j < NUM_VAR; j++){
// 		    for (int k = 0; k < SOS_SIZE; k++){
// 			inFile << sosobj[j][k] << "   ";
// 		    }
//   }
// 		inFile << endl;
// 		for (int j = NUM_VAR; j < NUM_VAR*2; j++){
// 		    for (int k = 0; k < SOS_SIZE; k++){
// 			inFile << sosobj[j][k]/2 << "   ";
// 		    }
// 		}
// 		inFile << endl << endl;
		
// ================================================================================================
// Setting the parameters of CPLEX
// ================================================================================================
          status = CPXsetintparam (env, CPXPARAM_OptimalityTarget,CPX_OPTIMALITYTARGET_OPTIMALGLOBAL);
          if ( status ) {
 	   fprintf(stderr, "Failed to Global Optimality");
 	   goto TERMINATE;
 	  }
 
//	  inFile <<"Solver set to qcp global solver" << endl;
 
	  status = CPXsetdblparam(env, CPXPARAM_TimeLimit, PWL_Tlimit);
	  if (status) {
	      fprintf(stderr, "Failed to change time limit to PWL_Tlimit seconds.\n");
	  }
//	  inFile << "Set CPLEX Time Limit to half an hour." << endl;
 
	  status = CPXsetintparam (env, CPXPARAM_LPMethod, CPX_ALG_AUTOMATIC);
         if ( status ) {
	     fprintf (stderr,
               "Failed to set the optimization method, error %d.\n", status);
	  goto TERMINATE;
	}
	
//	inFile << "Method set to automatic (primal simplex)\n";
	
// 	status = CPXsetintparam (env, CPXPARAM_Threads, 1);
// 	if (status) {
// 	  fprintf (stderr,
//                "Failed to set the threads, error %d.\n", status);
// 	  goto TERMINATE;}
	
	
//	inFile << "Method set to automatic (primal simplex)\n";	
// ================================================================================================ 
   
   
// ==================================================================================================
// 					STARTING THE ITERATIONS HERE!
// ==================================================================================================

      start_t = time(NULL);
      cpu_start = clock();
//      inFile <<"Begin CPU time for algorithm: "<< start_t << endl;
//      inFile << "============================= Start of Loop =============================" << endl;
 
   for (int step = 0; step < MAX_STEPS; step++){
     
// ==================================================================================================
// Generating LP relaxation problem using "generator" function
// ==================================================================================================	  
      
      Relaxationgenerator(step);
      //      Relaxationgenerator(0);
//      inFile << "Current step is: "<< step + 1 << endl;
      newlp = CPXcreateprob (env, &status, name_sos1_log.c_str());                         
 
      if ( newlp == NULL ) {
       fprintf (stderr, "Failed to create LP.\n");
       goto TERMINATE;
       }
// ================================================================================================== 
    /* Now read the file, and copy the data into the created lp (LP relaxation) */
// ================================================================================================== 
      status = CPXreadcopyprob(env,newlp,name_sos1_log.c_str(), NULL);
	if ( status ) {
	  fprintf (stderr, "Failed to read and copy the problem data.\n");
	  goto TERMINATE;
	} 
// ==================================================================================================
   
   /* Adding the SOS constraints to the problem. To do this, we first need to take the following steps:
     1) Changing the problem type to MIP
     2) Copying the SOS constraints to the problem using the function "copysos"*/
   
// ==================================================================================================
      
      
      status = CPXchgprobtype(env, newlp, 1);
      if ( status ) {
	  fprintf (stderr, "Failed to change problem type to MILP.\n");
	  goto TERMINATE;
	} 

      for (int i = 0; i < numsos; i++){
		sosvar[i][0]= i*2;
		sosvar[i][1]=i*2+1;
      }
      
      if (step==0){
	  sosbeg[0]=0;
// 	  inFile << "Starting indices for SOS sets are:" << endl;
// 	  inFile << "sosbeg[0]=" << sosbeg[0] << "  ";
	  for (int i = 1; i < numsos; i++){
	      sosbeg[i] = i*NUM_BKPTS;
//	      inFile << "sosbeg["<< i << "]=" << sosbeg[i] << "  "; 
	  }
//	  inFile << endl;
      }

      if (step!=0){ 
  
//	inFile << "SOS elements for step " << step + 1 <<":" << endl;
      
	sosbeg[0] = 0;
// 	inFile << endl;
//         inFile << "Starting indices for SOS sets are:" << endl;
// 	inFile << "sosbeg["<< 0 << "]" << " = " << sosbeg[0] << "   ";
	for (int i = 1; i < numsos; i++){
	   sosbeg[i] = NUM_BKPTS + countsos[step-1][i-1] + sosbeg[i-1];
//	   inFile << "sosbeg["<< i << "]" << " = " << sosbeg[i] << "   "; 
      	}
//         inFile << endl << endl;

	for (int i=0; i< numsos; i++){
	   sostype[i]='2';
//	   inFile << "sostype["<< i << "]" << " = " << sostype[i] << "   ";
	}
//	inFile << endl << endl;

//	inFile << "Index of each element of SOS2 sets in the LPR problem:" << endl; 
	for (int i=0; i< numsos; i++){
	  for (int j=0; j<NUM_BKPTS + countsos[step-1][i]; j++){
//	   sosind[sosbeg[i] + j]= sosvar[i][j];
	   sosind[sosbeg[i] + j] = sosbeg[i] + j;
//	   inFile << "sosind["<< sosbeg[i] + j << "]" << " = " << sosind[sosbeg[i] + j] << "   ";
	  }
	}
//	inFile << endl << endl;
	
//	inFile << "Adjacency array of SOS2 elements for each set is:" << endl; 
	for (int i=0; i< numsos; i++){
	  for (int j=0; j<NUM_BKPTS + countsos[step-1][i]; j++){
	   soswt[sosbeg[i] + j] = brkptsoswt[i][j];
//	   soswt[sosbeg[i] + j] = wj[j];
//	   inFile << "soswt["<< sosbeg[i] + j << "]" << " = " << soswt[sosbeg[i] + j] << "    ";
	  }
	}
//	inFile << endl;
//	inFile << "Total number of SOS2 elements is: "  << numsosnz << endl << endl; 


	status = CPXcopysos(env, newlp, numsos, numsosnz, sostype, sosbeg, sosind, soswt, NULL);
	if ( status ) {
	  fprintf (stderr, "Failed to copy SOS constraints to the LPR problem.\n");
	  goto TERMINATE;
	}
  
    }
      
// ==================================================================================================
      	  /*mystream << "LP_Relaxation" << step << ".lp";
	  name_Relaxation = mystream.str();			 // returns a string object with a copy of the current contents of the stream.
	  cout << " LP_Relaxation is " << name_Relaxation <<endl;*/
	  if (step!=0){
	  CPXwriteprob(env, newlp, "LP_Relax_Step1.lp", NULL); 
	  }
      
     
      status = CPXmipopt (env, newlp);
       if ( status ) {
	  fprintf (stderr, "Failed to optimize MILP.\n");
	  goto TERMINATE;
       }

      solnstat = CPXgetstat (env, newlp);

      if ( solnstat == CPX_STAT_UNBOUNDED ) {
	  printf ("Model is unbounded\n");
	  goto TERMINATE;
       }

      else if ( solnstat == CPX_STAT_INFEASIBLE ) {
	  printf ("Model is infeasible\n");
	  goto TERMINATE;
      }
      else if ( solnstat == CPX_STAT_INForUNBD ) {
	  printf ("Model is infeasible or unbounded\n");
	  goto TERMINATE;
      }

      status = CPXsolninfo (env, newlp, &solnmethod, &solntype, NULL, NULL);
      if ( status ) {
	  fprintf (stderr, "Failed to obtain solution info.\n");
	  goto TERMINATE;
      }
//      inFile << "Solution status " << solnstat << endl << "solution method " << solnmethod << endl << endl;

      if ( solntype == CPX_NO_SOLN ) {
	  fprintf (stderr, "Solution not available.\n");
	  goto TERMINATE;
      }

      status = CPXgetobjval (env, newlp, &lpobjval);
      if ( status ) {
	  fprintf (stderr, "Failed to obtain objective value.\n");
	  goto TERMINATE;
      }
//      inFile << "Objective value of the LP relaxation is: " << lpobjval << endl << endl;
      
// ================================================================================================== 
//    /* The size of the problem should be obtained by asking CPLEX what
//       the actual size is.  cur_numrows and cur_numcols store the
//       current number of rows and columns, respectively.  */
      
      cur_numcols = CPXgetnumcols (env, newlp);
      cur_numrows = CPXgetnumrows (env, newlp);

// ==================================================================================================
// Retrieve basis, if one is available */
// ================================================================================================== 
      if ( solntype == CPX_BASIC_SOLN ) {
	  cstat = (int *) malloc (cur_numcols*sizeof(int));
	  rstat = (int *) malloc (cur_numrows*sizeof(int));
	  if ( cstat == NULL || rstat == NULL ) {
	    fprintf (stderr, "No memory for basis statuses.\n");
	    goto TERMINATE;
	  }
 
      status = CPXgetbase (env, newlp, cstat, rstat);
      if ( status ) {
         fprintf (stderr, "Failed to get basis; error %d.\n", status);
         goto TERMINATE;
      }
   }
//      else {
//       inFile << "No basis available" << endl;
//      }
// ==================================================================================================
      
// ==================================================================================================
// Retrieve solution vector
// ================================================================================================== 
    x = (double *) malloc (cur_numcols*sizeof(double));
    if ( x == NULL ) {
	fprintf (stderr, "No memory for solution.\n");
	goto TERMINATE;
    }

    status = CPXgetx (env, newlp, x, 0, cur_numcols-1);
    if ( status ) {
	fprintf (stderr, "Failed to obtain primal solution.\n");
	goto TERMINATE;
    }
// ==================================================================================================
    
// ==================================================================================================
// Write out the solution 
// ==================================================================================================
    for (int j = 0; j < cur_numcols; j++) {
//	inFile << "Column " << j << ":" <<" Value = " << x[j] << endl;
	if ( cstat != NULL ) {
	  switch (cstat[j]) {
	      case CPX_AT_LOWER:
		basismsg = "Nonbasic at lower bound";
		break;
	      case CPX_BASIC:
		basismsg = "Basic";
		break;
	      case CPX_AT_UPPER:
		basismsg = "Nonbasic at upper bound";
		break;
	      case CPX_FREE_SUPER:
		basismsg = "Superbasic, or free variable at zero";
		break;
	      default:
		basismsg = "Bad basis status";
		break;
	  }
//	  inFile << "  " << basismsg;
	}
    }
//    inFile << endl;
// ==================================================================================================

// ==================================================================================================  
// Display the maximum bound violation.
// ==================================================================================================
      status = CPXgetdblquality (env, newlp, &maxviol, CPX_MAX_PRIMAL_INFEAS);
      if ( status ) {
	  fprintf (stderr, "Failed to obtain bound violation.\n");
	  goto TERMINATE;
      }
//      inFile << "Maximum bound violation = " << maxviol << endl<< endl;


// ==================================================================================================
// Relocate solution vector x to a 2D array L which contains the solutions (L11, L12, etc.) in the corresponding location in matrix L.
// ==================================================================================================

      // Ashley's implementation if using CPXchgcoeff() 
/*      for (int i = 0; i < NUM_VAR; i++){
	   for (int j = 0; j < NUM_BKPTS+step; j++){
		 L[i][j] = x[i* (NUM_BKPTS+step)+ j];}			
	  }*/
      
      // Amin's implementation if using  Relaxationgenerator() at every iteration
/*	for (int i = 0; i < NUM_VAR; i++){
	  if (step!=0){ 
	  for (int j = 0; j < NUM_BKPTS + countsos[step-1][i]; j++){
		 L[i][j] = x[j];}			
	  }
	  else {
	  for (int j = 0; j < NUM_BKPTS; j++){
		 L[i][j] = x[j];}			
	  }
	}
*/

		for (int i = 0; i < NUM_VAR; i++){
		  Sum_L[i] = 0;
		  if (step!=0){
		    for (int j = 0; j < NUM_BKPTS+countsos[step-1][i]; j++){
		      Sum_L[i]+=x[sosbeg[i]+j];}
		  }
		  else{
		    for (int j = 0; j < NUM_BKPTS; j++){
		      Sum_L[i]+=x[sosbeg[i]+j];}
		  }
		 }

    
/*	inFile << "Lambda variables for iteration no. "<< step + 1 <<" are:"<<endl;
		for (int i = 0; i < NUM_VAR; i++){
		  if (step!=0){
   		    inFile << "sosbeg[" << i << "]= " << sosbeg[i] << endl; 
		    for (int j = 0; j < NUM_BKPTS+countsos[step-1][i]; j++){
		    inFile << "L[" << i << "]" << "[" << j <<"]= "<< x[sosbeg[i]+j] << "  ";
		  }
		    inFile << "Sum_L[" << i << "]= " << Sum_L[i]; 
		    inFile << endl;
		  }
		  else{
		  for (int j = 0; j < NUM_BKPTS; j++){
		    inFile << "L[" << i << "]" << "[" << j <<"]= "<< x[sosbeg[i]+j] << "  ";
		  }
		    inFile << "Sum_L[" << i << "]= " << Sum_L[i];  
		    inFile << endl;
		  }
		}
	inFile << endl;*/	
// ==================================================================================================

// ==================================================================================================
//    Calculate new x values using L (i.e. using lambda solution values from first LP approx.)
//    Put new x values in an array called newx.
// ================================================================================================== 
    for (int i=0; i<NUM_VAR; i++){
      double sum = 0.0;
      if (step!=0){
// Ashley's implementation	    for (int j=0; j<NUM_BKPTS + step; j++)
	for (int j=0; j< NUM_BKPTS + countsos[step-1][i]; j++){
	    sum += brkpt[i][j]*x[sosbeg[i]+j];}
      }
      else{
	for (int j=0; j< NUM_BKPTS; j++){
	    sum += brkpt[i][j]*x[sosbeg[i]+j];}  
      }
	    newx[i] = sum;
    }
//     inFile << "new values of x and their corresponding obj values calculated using L, are:" << endl;
//     
// 
//     for (int i = 0; i < NUM_VAR; i++){
// 	   inFile << "newx["<< i << "]= " << newx[i] << "  ";}
// 	   
//     inFile << endl;
 
	   
//    Need to use newx and plug it into the original QCP objective from the first file.
   algobj = 0.0;
   for (int j = 0; j < NUM_VAR; j++)
   {

	   algobj += fjxj(newx[j],j);
//	   inFile << "fjxj = "<< fjxj(newx[j],j)<< "   ";
   }
   
   
// 	   inFile << endl;
// 	   inFile << "Objective Value of Original QCP using new x values: " << algobj << endl << endl; // Correct Objective Value
// ==================================================================================================

// ==================================================================================================
//    Calculating the new values of variables and the updated Obj value. 
// ==================================================================================================
 
     
	for (int i=0; i<NUM_VAR; i++){
	      X_Steps[step][i] = newx[i];
      }
      	      values[step] = algobj;

    

// ==================================================================================================
//    Check for repeated breakpoint values.  If repeated, set that elt of newx to 0.0.
//    Keep the other values as is.
// ==================================================================================================

   for (int i = 0; i < NUM_VAR; i++){
     for (int j = 0; j <NUM_BKPTS+step; j++){
		   if ((double)fabs(newx[i] - brkpt[i][j]) < .00000001){
			   newx[i] = 0.0;}}}
//   inFile << "After checking for repeated breakpoint values and adjusting as necessary:"<<endl;

// ==================================================================================================
// COUNTING THE NUMBER OF POINTS WITH SOLUTION BETWEEN THE BOUNDARIES (BETWEEN 0 AND 1)
// ==================================================================================================
   count = 0;
   for(int i = 0; i < NUM_VAR; i++){
	   if (newx[i] != 0){
		   count++;
		   if (step!=0){
				countsos[step][i] = countsos[step-1][i] + 1;
				sosvar[i][NUM_BKPTS - 1 + countsos[step][i]] = NUM_VAR*NUM_BKPTS + NUM_VAR*step + i;}
		   else {countsos[step][i] = 1;}
		   numsosnz++;
		   
//		   inFile << "countsos[" << step << "]" << "[" << i << "]" << "= " << countsos[step][i] << endl;
		   }
	   
	   else if (step!=0){
		    countsos[step][i] = countsos[step-1][i];}
	   else {countsos[step][i] = 0;}
	  }
//   inFile << endl;
//    inFile << "The new SOS2 elements are:" << endl;
//    inFile << "The new number of SOS2 elements is: "<<  numsosnz << endl << endl;
//    inFile << "The updated countsos for the current step is:" << endl;
//    for(int i = 0; i <= step; i++){
//     for(int j = 0; j < NUM_VAR; j++){
//      inFile << "countsos[" << i << "]" << "[" << j << "]" <<"= " << countsos[i][j] << "   ";
//     }
//      inFile << endl;
//    }
//    inFile << endl;
	   
// ==================================================================================================
   if (count == 0 || step + 1 == MAX_STEPS){
// 	   inFile << "There are no new breakpoints. Terminating..."<< endl;
// 	   inFile << "============================= Final Results =============================" << endl;
// 	   inFile << "Current step = "<< step + 1 << endl;
// 	   inFile << "Finished Problem Number "<< n << "of " << NUMBER_OF_DIFFERENT_PROBLEMS << endl;
	   end_t = time(NULL);
//	   inFile << "End of the algorithm loop: end_t = "<<end_t<<endl;
           algtime = ((double) (end_t - start_t));
// 	   inFile << "Elapsed Time for algorithm is " << end_t - start_t <<" ticks,"<<" or "<< algtime <<" seconds" << endl;
// 	   inFile << "The X values over the iterations are:" << endl;
// 	   for (int i = 0; i <= step; i++){
// 	     for (int j = 0; j < NUM_VAR; j++){
// 	       inFile << "X[" << i << "]" << "[" << j << "]= "<< X_Steps[i][j] << "    "; 
// 	     }
// 	     inFile << endl;
// 	   }
	   for (int i = 0; i<=step; i++){
//	     inFile << "ObjVal[" << i+1 << "]= " << values[i] << "   ";
	     inFile << values[i] << "   ";
	   }
	   inFile << endl;
	   summary(lpobjval, step, algobj,algtime,solnstat, solnmethod, solntype ); //Yang Yu Edit Sep 19
//	   summary(lpobjval, step, algobj,algtime);
	   break;
	   goto TERMINATE;}
//    else
//    {
//  	   inFile << "There are new breakpoints."<< endl;
//  	   inFile << "No. of new breakpoints: " << count << endl;
// 	  
// 	}
 
// ==================================================================================================


// ==================================================================================================
//    The next step is to add the array newx as an additional column of the 2D array brkpt.
// ==================================================================================================
//   inFile << "The new breakpoints are: " << endl;
   for (int i=0; i < NUM_VAR; i++){
     
     if (step == 0){
	if (countsos[step][i]==0){continue;}
	else{brkpt[i][NUM_BKPTS + countsos[step][i]-1] = newx[i];}
     }
     else if (countsos[step][i] == countsos[step-1][i]){continue;}
     else {brkpt[i][NUM_BKPTS + countsos[step][i]-1] = newx[i];
    }

  }
// //  cout << "brkp[2][2] = " << brkpt[2][2] << endl;
//      for (int i=0; i < NUM_VAR; i++){
//        inFile << "brkpt[" << i << "]" << "[" << NUM_BKPTS + step << "] " << "= " << brkpt[i][NUM_BKPTS + step] << "   ";
//      }
// 
//   inFile << endl << endl;
//   
// // ==================================================================================================
//        inFile << "The new array brkpt at iteration no "<< step+1 << " is:" << endl;
//     
//      for (int i =0; i< NUM_VAR; i++){
//       for (int j=0; j <= NUM_BKPTS+step; j++){
// ///      for (int j=0; j <= NUM_BKPTS+0; j++){
// 	inFile << "brkpt[" << i <<"]" << "[" << j << "]= " << brkpt[i][j] << "  ";
//       }
//       inFile << endl;
//     }
//     inFile << endl;
// ==================================================================================================
  
// ==================================================================================================
// Give ranks to the elements of the countsos matrix in order to use them for sos wieghts 
// ==================================================================================================
  
  for (int i=0; i < NUM_VAR; i++){
    for (int j=0; j < NUM_BKPTS + countsos[step][i]; j++){
      int rank=1;
      for(int k=0; k < NUM_BKPTS + countsos[step][i]; k++){
	if(brkpt[i][j]>brkpt[i][k])
	  rank++;
      }
       brkptsoswt[i][j]=rank;
    }
  }
//   inFile << "Rank matrix for brkpt matrix (used for adjacency of SOS2 elements):" << endl;  
//   for (int i=0; i < NUM_VAR; i++){
//     for (int j=0; j <= NUM_BKPTS + step; j++){
// 	  inFile << brkptsoswt[i][j] << "  ";
// 	}
// 	inFile << endl;
//     }
//     inFile << endl;
// ==================================================================================================

      
    

//      inFile << "================================================================================" << endl;
          
      } 				
// ==================================================================================================      
// 					  ENDING THE ITERATION HERE!
// ==================================================================================================



   inFile.close();
   
TERMINATE:
   cout << "Terminating\n";
   /* Free up the basis and solution */

   free_and_null ((char **) &cstat);
   free_and_null ((char **) &rstat);
   free_and_null ((char **) &x);

   /* Free up the problem, if necessary */

   if ( lp != NULL ) {
      status = CPXfreeprob (env, &lp);
      if ( status ) {
         fprintf (stderr, "CPXfreeprob failed, error code %d.\n", status);
      }
   }

   /* Free up the CPLEX environment, if necessary */

   if ( env != NULL ) {
      status = CPXcloseCPLEX (&env);

      /* Note that CPXcloseCPLEX produces no output,
         so the only way to see the cause of the error is to use
         CPXgeterrorstring.  For other CPLEX routines, the errors will
         be seen if the CPXPARAM_ScreenOutput indicator is set to CPX_ON. */

      if ( status ) {
         char  errmsg[CPXMESSAGEBUFSIZE];
         fprintf (stderr, "Could not close CPLEX environment.\n");
         CPXgeterrorstring (env, status, errmsg);
         fprintf (stderr, "%s", errmsg);
      }
   }

   
   return (status);
//	}

}


