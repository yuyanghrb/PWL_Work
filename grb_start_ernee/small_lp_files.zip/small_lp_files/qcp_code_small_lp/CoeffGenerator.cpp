#include "Funcs_Vars_MIQCP.h"
#include <ilcplex/ilocplex.h>
#include <iostream>
#include <fstream>
#include <ostream>
#include <stdio.h>
#include <ctype.h>
#include <stdlib.h>
#include <string.h>
#include <vector>
#include <math.h>
#include <ctime>
#include <time.h>
#include <iomanip>

using namespace std;

// Coefficient Generation Function
double Functions::CoeffGenerator(){

  ofstream inFile;
  inFile.open(name_sos1_log_debug.c_str());
// Generation of obj function coefficients (sosobj)
// -----------------------------------------------------------------------------------------------------------------------------------------------
 for (int i=0; i<NUM_VAR; i++) {                                            // Coefficients of linear terms in the Obj Function
     for (int j=SOS_SIZE-1; j>=0; j--) {
         if (j==SOS_SIZE-1) 
	 {sosobj[i][j] = rand()%5+1;
	 inFile << "The sosobj[" << i << "]" << "[" << j << "]" << " is " << sosobj[i][j] << endl;}
         else sosobj[i][j] = sosobj[i][j+1] + rand()%4+1;
  }
 }

 for (int i=NUM_VAR; i<NUM_VAR*2; i++) {                                    // Coefficients of quadratic terms in the Obj Function
	 for (int j=SOS_SIZE-1; j>=0; j--) {
		 if (j==SOS_SIZE-1) 
		 {sosobj[i][j] = sosobj[i-NUM_VAR][j]*(rand()%20 +10);
		   inFile << "The sosobj[" << i << "]" << "[" << j << "]" << " is " << sosobj[i][j]/2 << endl;}
		 else sosobj[i][j] = sosobj[i-NUM_VAR][j]*(rand()%20 + 10);
 }
}
// -----------------------------------------------------------------------------------------------------------------------------------------------


// Populating the A matrix
// -----------------------------------------------------------------------------------------------------------------------------------------------
 for (int i=0; i<NUM_ROWS; i++) {
     for (int j=0; j<NUM_VAR; j++) {
         for (int k=SOS_SIZE-1; k>=0; k--) {
            a[i][j][k] = 0;
	        aa[i][j][k] = 0;
      }
    }
  }

 for (int i=0; i<NUM_ROWS; i++) {                                           // Generating the A and b matrices (Ax = b) (a,rhs)
    max_a = 20.0;
    rhs[i] = 0.0;
    for (int j=0; j<NUM_VAR; j++) {                                         // Coefficients of linear terms in the constraints
        for (int k=SOS_SIZE-1; k>=0; k--) {
	       if (k==SOS_SIZE-1) 
	       {a[i][j][k] = rand()%5+1;
		 inFile << "The a[" << i << "]" << "[" << j << "]" << "[" << k << "]" << " is " << a[i][j][k] << endl;}
	       else a[i][j][k] = (int) ceil(sosobj[j][k]*a[i][j][k+1]/sosobj[j][k+1]) + 1 + rand()%5;
      }
        if (rand()%100>=DENSITY_SOS) continue;
        for (int k=0; k<SOS_SIZE; k++) {
	      if (rand()%100>=DENSITY_MEMBER) continue;
	      if (max_a > a[i][j][k]) max_a = a[i][j][k]/5;
          aa[i][j][k] = a[i][j][k];
      }
        rhs[i] += aa[i][j][SOS_SIZE-1];
    }

    for (int j=NUM_VAR; j<NUM_VAR*2; j++) {                                 // Coefficients of quadratics terms in the constraints
        for (int k=SOS_SIZE-1; k>=0; k--) {
	       if (k==SOS_SIZE-1) 
	       {a[i][j][k] = rand()%20+10;
		 inFile << "The a[" << i << "]" << "[" << j << "]" << "[" << k << "]" << " is " << a[i][j][k] << endl;}
	       else a[i][j][k] = (int) ceil(sosobj[j][k]*a[i][j][k+1]/sosobj[j][k+1]) + 1 + rand()%5;
      }
        if (rand()%100>=DENSITY_SOS) continue;
        for (int k=0; k<SOS_SIZE; k++) {
	      if (rand()%100>=DENSITY_MEMBER) continue;
	      if (max_a > a[i][j][k]) max_a = a[i][j][k]/5;
          aa[i][j][k] = a[i][j][k];
      }
	rhs[i] += aa[i][j][SOS_SIZE-1];
    }
    
    
    rhs[i] = floor(rhs[i] *.03);
//	if (rhs[i] < max_a + 1) rhs[i] = max_a + 1;
  }
  
  for (int i=0; i<NUM_ROWS; i++){
    inFile << "The rhs["<< i << "]"<< " is "<< rhs[i] << endl;
  }
// -----------------------------------------------------------------------------------------------------------------------------------------------
  inFile.close();
  return 0;
}