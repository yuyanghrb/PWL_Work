#ifndef FUNCS_VARS_H
#define FUNCS_VARS_H

#include <string>
#include <vector>
#include <iostream>

#include <ilcplex/ilocplex.h>
#include <fstream>
#include <ostream>
#include <stdio.h>
#include <ctype.h>
#include <stdlib.h>
#include <string.h>
#include <vector>
#include <math.h>
#include <ctime>
#include <time.h>
#include <iomanip>

class Functions{
  
  private:
	std::string name_sos1_log1;
	std::string name_sos1_logM;
	std::string name_sos1_log2;
        std::string name_sos1_log;
 	std::string name_sos1_log_debug;
	std::string name_sos1_log_debug1;
	std::string count_sos;
	std::string LP_relaxation;
	std::string Summary;
	std::string CPX_Summary;
	const static int NUM_VAR=2500 ;
	const static int NUM_ROWS= NUM_VAR / 10;
	const static int SOS_SIZE = 1;                     	     /* each SOS set has SOS_SIZE members*/
	const static int DENSITY_SOS = 80;                	     /* expected percentage of SOS sets in each row */
	const static int DENSITY_MEMBER = 80;             	     /* expected percentage of SOS members in each SOS set*/
	const static int NUMBER_OF_DIFFERENT_PROBLEMS = 15, NUM_BKPTS = 2, MAX_STEPS=30, MAX_BKPTS = MAX_STEPS + 2, CPX_Tlimit=7200, PWL_Tlimit = CPX_Tlimit / 15;
	double sosobj[NUM_VAR*2][SOS_SIZE];
	double max_a, a[NUM_ROWS][NUM_VAR*2][SOS_SIZE], aa[NUM_ROWS][NUM_VAR][SOS_SIZE], brkpt[NUM_VAR][MAX_BKPTS];
	std::vector <double> rhs; 
	int countsos[MAX_STEPS][NUM_VAR];
	
  public:

	 Functions();
	 void set(int i, int j);
	 int getnumprob();
	 void CharSet(int l);
	 double CoeffGenerator();
	 void Relaxationgenerator(int st);
	 int ipopt();
 	 void generator();
         void generator1();
	 void generator2();
//         void summary(double lpobjval, int step, double algobj, long double algtime);
		 
	void summary(double lpobjval, int step, double algobj, long double algtime,int solnstat,int solnmethod,int solntype);
	 int CPX();
	 void free_and_null (char **ptr);     // This simple routine frees up the pointer *ptr, and sets *ptr to NULL //
	 void usage (char *progname);
         double fjxj(double xj, int j);  	// Function to compute f_j(x_j)
	 double Cjxj(double xj, int i, int j);
	 int Algorithm(int n);
};


#endif // FUNCS_VARS_H
