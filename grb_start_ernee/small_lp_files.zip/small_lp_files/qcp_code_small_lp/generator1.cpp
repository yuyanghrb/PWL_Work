#include "Funcs_Vars_MIQCP.h"
#include <ilcplex/ilocplex.h>
#include <iostream>
#include <fstream>
#include <ostream>
#include <stdio.h>
#include <ctype.h>
#include <stdlib.h>
#include <string.h>
#include <vector>
#include <math.h>
#include <ctime>
#include <time.h>
#include <iomanip>

using namespace std;

void Functions::generator1(){


//================================================
// Begin writing to LP file
//================================================  
  int count;
  ofstream LPFile;

  LPFile.open(name_sos1_log1.c_str());


  int lgT[NUM_VAR];

  for (int j=0; j<NUM_VAR; j++) {
    lgT[j] = int ((log(SOS_SIZE-0.1)/log(2)) + 1);
  }

  LPFile<<"Minimize"<<endl<<endl;

  LPFile<<"Obj: ";

// Coefficients of first order variables in the Obj function.
//---------------------------------------------------------------------------------------------------
  for (int i=0; i<NUM_VAR; i++) {
    count = 0;
    for (int j=0; j<SOS_SIZE; j++) {
      LPFile<<sosobj[i][j]<<" x_"<<i<<"_"<<j;
      count++;
	  if (count == SOS_SIZE) LPFile<<endl;  //original that works for small problems

      if ((i<NUM_VAR-1)||(j<SOS_SIZE-1)) LPFile<<" + ";
      else LPFile<<endl;
    }
	LPFile.flush();
  }
//---------------------------------------------------------------------------------------------------

// Coefficients of second order variables in the Obj function.
//--------------------------------------------------------------------------------------------------
  LPFile<<" + [ - ";
  //  TO FIX: i = NUM_VAR; i < NUM_VAR*2; i++ and adjust endl " - " accordingly.
  for (int i=0; i<NUM_VAR; i++) {
    count = 0;
    for (int j=0; j<SOS_SIZE; j++) {
	  LPFile<<sosobj[i+NUM_VAR][j]<<" x_"<<i<<"_"<<j<<"* x_"<<i<<"_"<<j/*<<" - "*/;  // Same numbers as lin, but divided by 2
	  count++;
	  LPFile.flush();
      if (count == SOS_SIZE) LPFile<<endl;
      if ((i<NUM_VAR-1)||(j<SOS_SIZE-1)) LPFile<<" - ";

      else LPFile<<" ] / 2 "<<endl;
    }
  }
//---------------------------------------------------------------------------------------------------


// Constraints, their coefficients, and right hand side matrices:
//---------------------------------------------------------------------------------------------------
  LPFile<<endl<<"Subject to"<<endl<<endl;

  for (int i=0; i<NUM_ROWS; i++) {
    LPFile<<"c_"<<i<<": ";
    for (int j=0; j<NUM_VAR; j++) {                                                     // Coefficients of the first order variables in the constraints:
      count = 0;
      for (int k=0; k<=SOS_SIZE-1; k++) {
	    LPFile<<a[i][j][k]<<" x_"<<j<<"_"<<k;
	    count++;
	    if (count == SOS_SIZE) LPFile<<endl;
	    if ((j<NUM_VAR-1)||(k<SOS_SIZE-1)) LPFile<<" + ";
      }
    }

     LPFile<<" + [ ";
     for (int j=0; j<NUM_VAR; j++) {                                             	// Coefficients of the second order variables in the constraints:
       count = 0;
      for (int k=0; k<=SOS_SIZE-1; k++) {
	    LPFile<<a[i][j+NUM_VAR][k]<<" x_"<<j<<"_"<<k<<"* x_"<<j<<"_"<<k;
//	    cout << a[i][j+NUM_VAR][k] << endl;
	    count++;
	    if (count == SOS_SIZE) LPFile<<endl;
	    if ((j+NUM_VAR<NUM_VAR*2-1)||(k<SOS_SIZE-1)) LPFile<<" + ";
//	    if ((j<NUM_VAR*2-1)||(k<SOS_SIZE-1)) LPFile<<" + ";
      }
    }

    LPFile<<"] <= "<<rhs[i]<<endl<<endl;
  }

  LPFile<<endl;
//--------------------------------------------------------------------------------------------------


// Bounds
//---------------------------------------------------------------------------------------------------
  LPFile<<"Bounds "<<endl<<endl;

  for (int j=0; j<NUM_VAR; j++) {
    for (int k=SOS_SIZE-1; k>=0; k--) {
	LPFile<<"0 <= x_"<<j<<"_"<<k<<" <= 1"<<endl;
    }
  }

  LPFile<<endl;

  LPFile<<"End"<<endl;

  LPFile.close();
  
  
  
//================================================
// Begin writing to Mod file
//================================================

  ofstream modfile;
  

// Define Variables and Upper and lower bounds//
  modfile.open(name_sos1_logM.c_str());

  modfile << "option solver baron;" << endl;
  modfile << "option baron_options 'maxtime "<< CPX_Tlimit <<" ';" << endl;
  modfile << endl;

  for (int j=0; j<NUM_VAR; j++){
	modfile << "var x" << j << " >= " << 0 << ", <= " << 1 << " ;" << endl;
  }
  modfile << endl;

// Define Min Obj//
  modfile << "minimize obj: ";
  for (int j=0; j<NUM_VAR; j++){
	modfile << endl;
	modfile << "-" << (sosobj[j+NUM_VAR][SOS_SIZE-1])/2 << " * x" << j << "^2 + " << sosobj[j][SOS_SIZE-1] << " * x" << j;
  }
  modfile << ";" << endl;
  modfile << endl;

// Define the constrans
  modfile << "s.t." << endl;
  for (int i=0; i<NUM_ROWS; i++){
  	modfile << "C" << i << ": ";  
	for (int j=0; j<NUM_VAR; j++){
		modfile << endl;
		modfile << "+" << a[i][j+NUM_VAR][SOS_SIZE-1] << " * x" << j << "^2 + " << a[i][j][SOS_SIZE-1] << " * x" << j;
	}
	modfile << "<= " << rhs[i] << ";" << endl;
  }
  modfile << endl;

// ipopt Starting point:
//   for (int j=0; j<NUM_VAR; j++){
// 	modfile << "let x" << j << " := 0;" << endl;
//   }
//   modfile << endl;

//AMPL solve the mod and display objective value and solve time//
  
  modfile << "solve > result_ipopt_qcqp_" << NUM_VAR << "_" << NUM_ROWS << "_" << NUMBER_OF_DIFFERENT_PROBLEMS << ".txt;" << endl;
  modfile << endl;
  modfile << "display _nvars;" << endl;
  modfile << "display _ncons;" << endl;
  modfile << "display obj;" << endl;
  modfile << "display _solve_time;" << endl;
  
  for (int j=0; j<NUM_VAR; j++){
	modfile << "display x" << j << " ;" << endl;
  }
  modfile << endl;
  
  
  modfile.close();

}
//---------------------------------------------------------------------------------------------------
