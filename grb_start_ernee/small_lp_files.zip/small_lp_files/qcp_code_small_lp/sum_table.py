# -*- coding: utf-8 -*-
"""
Created on Wed Nov  8 18:25:27 2017

@author: Harsh
"""

nvars = []
ncons = []
obj = []
solve_time = []
with open('sum_mod.txt', 'r') as file:
    for line in file:
        if line.startswith('_nvars'):
            a = line[line.find('=') + 1:].strip()
            nvars.append(a)
            continue
        if line.startswith('_ncons'):
            b = line[line.find('=') + 1:].strip()
            ncons.append(b)
            continue
        if line.startswith('obj'):
            c = line[line.find('=') + 1:].strip()
            obj.append(c)
            continue
        if line.startswith('_solve_time'):
            d = line[line.find('=') + 1:].strip()
            solve_time.append(d)
            continue

fout = open('table.txt', 'w')
for row in range(len(nvars)):
    fout.write(nvars[row] + '\t' + ncons[row] + '\t' + obj[row] + '\t' +  solve_time[row] + '\n')

fout.close()
        