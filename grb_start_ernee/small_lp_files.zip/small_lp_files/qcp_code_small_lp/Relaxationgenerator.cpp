#include "Funcs_Vars_MIQCP.h"
#include <ilcplex/ilocplex.h>
#include <iostream>
#include <fstream>
#include <ostream>
#include <stdio.h>
#include <ctype.h>
#include <stdlib.h>
#include <string.h>
#include <vector>
#include <math.h>
#include <ctime>
#include <time.h>
#include <iomanip>

using namespace std;

// All the functions required in the Algorithm.cpp file
//-------------------------------------------------------------------------------
 void Functions::Relaxationgenerator(int st){
//   double bkpt[2] = {0, 1};
   
   ofstream datafile;
   int count, sos[NUM_VAR];
   datafile.open(name_sos1_log.c_str());
   
   
//-------------------------------------------------------------------------------
// Forming an array for using the updated countsos[][]
//-------------------------------------------------------------------------------   
   if (st==0){
     for (int i=0; i<NUM_VAR; i++){
       sos[i]= countsos[st][i];}    
   }
   else{
     for (int i=0; i<NUM_VAR; i++){
       sos[i] = countsos[st-1][i];
     }
     
   }
   
//-------------------------------------------------------------------------------  

//-------------------------------------------------------------------------------   
// Objective Function in the LP Relaxation problem
//-------------------------------------------------------------------------------
   datafile<<"Minimize"<<endl<<endl;
 
   datafile<<"Obj: ";
 
   for (int i = 0; i < NUM_VAR; i++)
       {
//	   for (int j= 0; j < sizeof(brkpt[0])/sizeof(brkpt[0][0]); j++)  // Here, we choose j < 2 because 2 is the length of bkpt[] = [0 1].
	   for (int j= 0; j < NUM_BKPTS+sos[i]; j++)
		{
//		  if (j>0 && brkpt[i][j]< 0.000001) continue;
			   if (fjxj(brkpt[i][j], i) < 0)
				datafile << " " << fjxj(brkpt[i][j],i) << " L_" << i+1 << "_" << j + 1 ;
			   else
			   if (i == 0 && j == 0)
				datafile << fjxj(brkpt[i][j],i) << " L_" << i+1 << "_" << j+1;
			   else
			        datafile << " + " << fjxj(brkpt[i][j],i) << " L_" << i+1 << "_" << j+1;
//			   if (j == NUM_VAR - 1 && j == (NUM_BKPTS+st) - 1)
		   datafile << endl;
	      }
      }

//-------------------------------------------------------------------------------

//-------------------------------------------------------------------------------
// Constraints in the LP Relaxation problem
//-------------------------------------------------------------------------------
  datafile<<endl<<"Subject to"<<endl<<endl;

  for (int i = 0; i < NUM_ROWS; i++)
  {
	  for (int j = 0; j < NUM_VAR; j++)
	  {
//		  for (int k = 0; k < sizeof(brkpt[0])/sizeof(brkpt[0][0]); k++)  // Here k < 2 since length of array bkpt is 2 (bkpt = [0 1]).
		  for (int k = 0; k < NUM_BKPTS+sos[j]; k++)
		  {
//			if (k>0 && brkpt[j][k] < 0.0000001) continue;

			if (Cjxj(brkpt[j][k],i,j) < 0)
				datafile << Cjxj(brkpt[j][k],i,j) <<" L_" << j+1 << "_" << k+1;
			else

			if (j == 0 && k==0)
				datafile << Cjxj(brkpt[j][k],i,j) << " L_" << j+1 << "_" << k+1;
			else
				datafile << " + " << Cjxj(brkpt[j][k],i,j) << " L_" << j+1 << "_" << k+1;
//			if (j == NUM_VAR - 1 && k == sizeof(brkpt[0])/sizeof(brkpt[0][0]) - 1)
//		if (j == NUM_VAR - 1 && k == (NUM_BKPTS+st) - 1)
//				datafile << " <= " << rhs[i];
		  }
	  }
	  datafile << " <= " << rhs[i];
	  datafile << endl;
  }

// Only for the very first step in relaxation

  

  for (int i=0; i<NUM_VAR; i++) {
    for (int j=0; j<NUM_BKPTS+sos[i]; j++) {
      if (j==0) {datafile<<"L_"<<i+1<<"_"<<j+1;}
//      else if (j > 0 && brkpt[i][j] < 0.00001) {continue;} 
      else {datafile<< " + "<< "L_"<<i+1<<"_"<<j+1;}
//      if (j == NUM_BKPTS+st-1) datafile<<" = " << 1 << endl;
//      else datafile<<" + ";
//        datafile<<" + ";
	}
  datafile<<" = " << 1 << endl;
  }
  datafile<<endl<<endl;
//-------------------------------------------------------------------------------
  
//-------------------------------------------------------------------------------
// Bounds on the Lambdas 
//-------------------------------------------------------------------------------
  
  datafile<<"Bounds "<<endl<<endl;

  for (int j=0; j<NUM_VAR; j++) {
    for (int k=0; k<NUM_BKPTS+sos[j]; k++) {
//      if (k > 0 && brkpt[j][k] < 0.00001) continue;
	datafile<<"0 <= L_"<<j+1<<"_"<<k+1<<" <= 1"<<endl;
    }
  }

  datafile<<endl;
  datafile<<endl;
  datafile<<"End"<<endl;
  datafile.close();
  
//-------------------------------------------------------------------------------  
// Copying the content of the LP relaxation file to another file
//-------------------------------------------------------------------------------
  ofstream b;
  ifstream a;
  char ch;
  a.open(name_sos1_log.c_str()); 				//The file from which the content will be copied
  b.open(LP_relaxation.c_str(), fstream::out | fstream::app); 	//The file to which the content will be copied
  while (!a.eof())
   {
    a.get(ch); 							//reading from file object 'a'
    b<<ch;     							//writing to file babli.txt
    }
  a.close();
  b.close();
//-------------------------------------------------------------------------------  
   
  
}
  
//-------------------------------------------------------------------------------


double Functions::fjxj(double xj, int j){
     return(sosobj[j][SOS_SIZE-1]*xj - sosobj[j+NUM_VAR][SOS_SIZE-1]/2*xj*xj);
}

double Functions::Cjxj(double xj, int i, int j){
    return(a[i][j][SOS_SIZE-1]*xj + a[i][j+NUM_VAR][SOS_SIZE-1]*xj*xj);
}

// void Functions::summary(char *summaryfile, double lpobjval, int step, double algobj, double algtime){
// 
// 
// 	ofstream datafile;
// 	datafile.open(summaryfile,ios::app);
// 
// 	datafile << left << setw(10) << setfill(' ') <<  algobj;
// 	datafile << left << setw(10) << setfill(' ') <<  algtime;
// 	datafile << left << setw(10) << setfill(' ') <<  step + 1 << endl;
// 
// 	datafile.close();
// }

void Functions::free_and_null (char **ptr){

   if ( *ptr != NULL ) {
      free (*ptr);
      *ptr = NULL;
   }
}

void Functions::usage (char *progname){

   fprintf (stderr,"Usage: %s filename optimalitytarget\n", progname);
   fprintf (stderr,"   where filename is a file with extension \n");
   fprintf (stderr,"      MPS, SAV, or LP (lower case is allowed)\n");
   fprintf (stderr,"   optimalitytarget is the optimality target:\n");
   fprintf (stderr,"      c          for a convex qp\n");
   fprintf (stderr,"      f          for a first order solution\n");
   fprintf (stderr,"      g          for the global optimum\n");
   fprintf (stderr," Exiting...\n");
}
//-------------------------------------------------------------------------------

