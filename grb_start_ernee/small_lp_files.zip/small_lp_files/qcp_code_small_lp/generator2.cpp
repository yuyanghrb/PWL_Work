#include "Funcs_Vars_MIQCP.h"
#include <ilcplex/ilocplex.h>
#include <iostream>
#include <fstream>
#include <ostream>
#include <stdio.h>
#include <ctype.h>
#include <stdlib.h>
#include <string.h>
#include <vector>
#include <math.h>
#include <ctime>
#include <time.h>
#include <iomanip>

using namespace std;

void Functions::generator2(){
	double l=0, u=1, max_a, colobj;
	int count;

	ofstream datafile;
	//Begin writing to file
	int lgT[NUM_VAR];

	for (int j=0; j<NUM_VAR; j++) {
		lgT[j] = int ((log(SOS_SIZE-0.1)/log(2)) + 1);
  }

  datafile.open(name_sos1_log2.c_str());

  for (int i=0; i<NUM_ROWS; i++) {
    for (int j=0; j<NUM_VAR*2; j++) {
      count = 0;
      for (int k=0; k<=SOS_SIZE-1; k++) {
	datafile<<a[i][j][k]<<" ";
	count++;
      }

    }
	 datafile<<endl;

  }
  datafile.close();
}


