#include "Funcs_Vars_MIQCP.h"
#include <ilcplex/ilocplex.h>
#include <iostream>
#include <fstream>
#include <ostream>
#include <stdio.h>
#include <ctype.h>
#include <stdlib.h>
#include <string.h>
#include <vector>
#include <math.h>
#include <ctime>
#include <time.h>
#include <iomanip>

using namespace std;



void Functions::summary(double lpobjval, int step, double algobj, long double algtime,int solnstat,int solnmethod,int solntype){


	ofstream datafile;
	datafile.open(Summary.c_str(),ios::app);

	datafile << left << setw(10) << setfill(' ') <<  algobj;
	datafile << left << setw(10) << setfill(' ') <<  algtime;
	datafile << left << setw(10) << setfill(' ') <<  step + 1;
	datafile << left << setw(10) << setfill(' ') <<  solnstat;
	datafile << left << setw(10) << setfill(' ') <<  solnmethod;
	datafile << left << setw(10) << setfill(' ') <<  solntype << endl;

	datafile.close();
}

 




