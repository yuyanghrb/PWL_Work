#!/bin/bash

g++ -c -m64 -fPIC -I/$CPLEXINC -I/$CONCERTINC -DIL_STD Algorithm-Final.cpp -o Algorithm-Final.o -w

g++ -c -m64 -fPIC -I/$CPLEXINC -I/$CONCERTINC -DIL_STD CoeffGenerator.cpp -o CoeffGenerator.o -w

g++ -c -m64 -fPIC -I/$CPLEXINC -I/$CONCERTINC -DIL_STD Funcs_Vars_MIQCP.cpp -o Funcs_Vars_MIQCP.o -w 

g++ -c -m64 -fPIC -I/$CPLEXINC -I/$CONCERTINC -DIL_STD generator1.cpp -o generator1.o -w

g++ -c -m64 -fPIC -I/$CPLEXINC -I/$CONCERTINC -DIL_STD generator2.cpp -o generator2.o -w

g++ -c -m64 -fPIC -I/$CPLEXINC -I/$CONCERTINC -DIL_STD ipoptsolve.cpp -o ipoptsolve.o -w

g++ -c -m64 -fPIC -I/$CPLEXINC -I/$CONCERTINC -DIL_STD Relaxationgenerator.cpp -o Relaxationgenerator.o -w 

g++ -c -m64 -fPIC -I/$CPLEXINC -I/$CONCERTINC -DIL_STD summary.cpp -o summary.o -w

g++ -c -m64 -fPIC -I/$CPLEXINC -I/$CONCERTINC -DIL_STD main.cpp -o main.o -w

g++ -m64 -fpic -I/$CPLEXINC -I/$CONCERTINC main.o summary.o Relaxationgenerator.o ipoptsolve.o generator2.o generator1.o Funcs_Vars_MIQCP.o CoeffGenerator.o Algorithm-Final.o -o New_pcws_baron.exe -L/$CPLEXLIB -L/$CONCERTLIB -lilocplex -lconcert -lcplex -lm -lpthread -w

rm *.o


