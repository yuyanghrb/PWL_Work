/* Gen.cpp - Generates random nonconvex quadratic
programming problems and an accompanying data.txt
file which contains the matrix of coefficients for the
constraint matrix. */

#ifdef _MSC_VER
#define _CRT_SECURE_NO_WARNINGS
#endif

#include "Funcs_Vars_MIQCP.h"
#include <ilcplex/ilocplex.h>
#include <iostream>
#include <fstream>
#include <ostream>
#include <stdio.h>
#include <ctype.h>
#include <stdlib.h>
#include <string.h>
#include <vector>
#include <math.h>
#include <ctime>
#include <time.h>
#include <iomanip>
#include <sys/stat.h>

using namespace std;

int main (int argc, char *argv[])
{
   
//      int seed;
      int stat;
      long double difftime_Alg, difftime_CPX, difftime_Sleep;  
      clock_t begin, end;

      Functions Amin;
      
	for (int m=1; m<=Amin.getnumprob(); m++) {

//	  seed = 1;
 
	  Amin.CharSet(m);
	  Amin.CoeffGenerator();		// The generated outputs are: a[NUM_ROWS][NUM_VAR*2][SOS_SIZE], rhs[NUM_ROWS], sosobj[NUM_VAR*2][SOS_SIZE]
	  Amin.generator1();
//	  Amin.generator2();
//	  Amin.generator();
	  Amin.ipopt();
	  
//	  begin = time(NULL);
//	  Amin.CPX();
//	  end = time(NULL);
//	  difftime_CPX = ((double) (end - begin));
	  
	  
//	  begin = time(NULL);
	  Amin.Algorithm(m);
//	  end = time(NULL);
//	  difftime_Alg = ((double) (end - begin));
	  
	  
	   
//	  cout << "difftime_Sleep is: " << difftime_Sleep <<endl;
//	  cout << "difftime_Alg is: " << difftime_Alg <<endl;
//	  cout << "difftime_CPX is: " << difftime_CPX <<endl;
      
//	  ++seed;
	}
	
//run the sh file to get AMPL mods results
//    	system("sh multi_mod.sh > sum_mod.txt");

//convert sum.txt to a table.txt
//        system("python sum_table.py");

//Create folder and Move files

        system("mkdir LP_files");
        system("mv *.lp LP_files");
        system("mkdir Mod_files");
        system("mv *.mod Mod_files");
        system("mkdir Relaxations_files");
        system("mv LP_Relaxations* Relaxations_files");
        system("mkdir Debug_files");
        system("mv DebugResults* Debug_files");
    }
