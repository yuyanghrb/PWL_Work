ampl QCP_400_40_1_80_80_1.mod
