#%%
from typing import ValuesView
from docplex.mp.model_reader  import ModelReader 

LP_model = ModelReader()
mdl = LP_model.read_model('QCP_10_1_1_80_80_1.lp')

mdl.print_information()
#%% 

c1 = mdl.get_constraint_by_index(1)

'''
get_constraint_by_index

Searches for a linear constraint from an index.

Returns the linear constraint with idx as index, or None. 
This function will not raise an exception if no constraint with this index is found.

NOT WORKING

'''
#%%

result1 = mdl.iter_quadratic_constraints()

for idx, quad_contr in enumerate(result1):
    print(idx)
    print(type(quad_contr))

# only one constraint (equation)
#(help(quad_contr))

vars_results = mdl.iter_variables()
var_list = []


for idx, varname in enumerate(vars_results):
    print(idx)
    print(varname.to_string())
    var_list.append(varname)



quad_expr = quad_contr.get_left_expr()
for var in var_list:
    print(var.name)
    print(quad_expr.get_quadratic_coefficient(var))

'''
x_1_0
23.0

x_2_0
10.0

x_3_0
12.0

'''

#%%
linear_expr = quad_expr.get_linear_part()
for var in var_list:
    print(var.name)
    print(linear_expr.get_coef(var))

'''
x_0_0
2.0
x_1_0
5.0
x_2_0
1.0
x_3_0
3.0s
'''

#%%
Solution = mdl.solve()
#Error: Model is non-convex

# print(int(Solution.objective_value))
# %%